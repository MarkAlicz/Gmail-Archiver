using System;
using System.Collections.Generic;

using Newtonsoft.Json;

namespace IVolt.Core.Email.Gmail
{
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// Read surface over a loaded local archive. Passed to plugins and used by the search subsystem
    /// so callers never touch raw folder layout directly.
    /// </summary>
    /// <remarks> I Volt, 6/30/2026. </remarks>
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    public interface IArchiveContext
    {
        /// <summary>Sanitized account key (e.g. markalicz_gmail_com).</summary>
        string AccountKey { get; }

        /// <summary>Root archive folder for this account.</summary>
        string ArchiveFolder { get; }

        /// <summary>Attachment ZIP folder for this account.</summary>
        string AttachmentsFolder { get; }

        /// <summary>Lucene index folder for this account.</summary>
        string IndexFolder { get; }

        /// <summary>The loaded manifest (counts, high-water marks, id -> pointer map).</summary>
        Archive_Manifest Manifest { get; }

        /// <summary>Enumerate every stored archive record, streamed from disk.</summary>
        IEnumerable<Archive_Record> EnumerateRecords();

        /// <summary>Load a single record by its archive pointer, or null if absent.</summary>
        Archive_Record LoadRecord(long archivePointer);

        /// <summary>Full path to the attachment ZIP for a given archive pointer (may not exist).</summary>
        string AttachmentZipPath(long archivePointer);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// Persistent manifest for one account. Written incrementally during archival; enables O(1) resume,
    /// de-duplication by Gmail message id, and instant summary reporting. Rebuildable from the archive
    /// tree if lost.
    /// </summary>
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    public class Archive_Manifest
    {
        [JsonProperty("account_key")]
        public string account_key { get; set; }

        [JsonProperty("email")]
        public string email { get; set; }

        /// <summary>Next archive pointer to assign.</summary>
        [JsonProperty("next_pointer")]
        public long next_pointer { get; set; }

        /// <summary>Total messages archived.</summary>
        [JsonProperty("message_count")]
        public long message_count { get; set; }

        /// <summary>Total attachments archived.</summary>
        [JsonProperty("attachment_count")]
        public long attachment_count { get; set; }

        /// <summary>Earliest message date seen (ISO 8601), for summary reporting.</summary>
        [JsonProperty("earliest_date")]
        public string earliest_date { get; set; }

        /// <summary>Latest message date seen (ISO 8601), for summary reporting.</summary>
        [JsonProperty("latest_date")]
        public string latest_date { get; set; }

        /// <summary>Highest IMAP UID processed in the primary mailbox (fetch optimization).</summary>
        [JsonProperty("high_water_uid")]
        public uint high_water_uid { get; set; }

        /// <summary>UIDVALIDITY of the mailbox the high-water UID belongs to.</summary>
        [JsonProperty("uid_validity")]
        public uint uid_validity { get; set; }

        /// <summary>Map of X-GM-MSGID -> archive pointer. The authoritative dedup/skip set.</summary>
        [JsonProperty("seen")]
        public Dictionary<string, long> seen { get; set; } = new Dictionary<string, long>();

        [JsonProperty("last_run_utc")]
        public string last_run_utc { get; set; }

        public static Archive_Manifest FromJson(string json) =>
            JsonConvert.DeserializeObject<Archive_Manifest>(json);

        public string ToJson() =>
            JsonConvert.SerializeObject(this, Formatting.Indented);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// One stored message record. This is the serialized archive form written per message into the
    /// BYMONTH tree. It is deliberately flat and self-describing so search/rebuild never needs the
    /// original transport.
    /// </summary>
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    public class Archive_Record
    {
        [JsonProperty("archive_pointer")]
        public long archive_pointer { get; set; }

        [JsonProperty("gm_msgid")]
        public string gm_msgid { get; set; }

        [JsonProperty("gm_thrid")]
        public string gm_thrid { get; set; }

        [JsonProperty("gm_labels")]
        public List<string> gm_labels { get; set; } = new List<string>();

        [JsonProperty("uid")]
        public uint uid { get; set; }

        [JsonProperty("raw_sha256")]
        public string raw_sha256 { get; set; }

        [JsonProperty("message_id")]
        public string message_id { get; set; }

        [JsonProperty("date")]
        public string date { get; set; }              // ISO 8601

        [JsonProperty("internal_date")]
        public string internal_date { get; set; }

        [JsonProperty("subject")]
        public string subject { get; set; }

        [JsonProperty("from")]
        public string from { get; set; }

        [JsonProperty("to")]
        public List<string> to { get; set; } = new List<string>();

        [JsonProperty("cc")]
        public List<string> cc { get; set; } = new List<string>();

        [JsonProperty("bcc")]
        public List<string> bcc { get; set; } = new List<string>();

        [JsonProperty("headers")]
        public List<KeyValuePair<string, string>> headers { get; set; } = new List<KeyValuePair<string, string>>();

        [JsonProperty("text_body")]
        public string text_body { get; set; }

        [JsonProperty("html_body")]
        public string html_body { get; set; }

        [JsonProperty("attachments")]
        public List<Archive_Attachment> attachments { get; set; } = new List<Archive_Attachment>();

        /// <summary>Relative path (from archive root) to this record's JSON file.</summary>
        [JsonProperty("record_path")]
        public string record_path { get; set; }

        /// <summary>Relative path to this record's attachment ZIP, if any.</summary>
        [JsonProperty("attachment_zip")]
        public string attachment_zip { get; set; }

        public static Archive_Record FromJson(string json) =>
            JsonConvert.DeserializeObject<Archive_Record>(json);

        public string ToJson() =>
            JsonConvert.SerializeObject(this, Formatting.Indented);
    }

    public class Archive_Attachment
    {
        [JsonProperty("file_name")]
        public string file_name { get; set; }

        [JsonProperty("content_type")]
        public string content_type { get; set; }

        [JsonProperty("content_id")]
        public string content_id { get; set; }

        [JsonProperty("size_bytes")]
        public long size_bytes { get; set; }

        /// <summary>Entry name inside the attachment ZIP.</summary>
        [JsonProperty("zip_entry")]
        public string zip_entry { get; set; }

        /// <summary>True when text was extracted and indexed; false for images/binaries.</summary>
        [JsonProperty("content_indexed")]
        public bool content_indexed { get; set; }
    }
}
