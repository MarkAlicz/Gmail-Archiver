# IVolt Gmail IMAP Archiver — Processing Engine

Ten source files plus a `.csproj`. This is the orchestrator that ties together the
configuration manager, the message container, and the processor you built in prior turns,
and adds the fetch loop, storage, indexing, search, and plugin subsystems.

## Files

| File | Responsibility |
|------|----------------|
| `Program.cs` | `Email_Archiver.exe` entry point. |
| `Email_Archiver_Engine.cs` | Startup screen, config verification, main menu, connection-test diagnostics, summary, search UI, plugin UI. |
| `Gmail_Fetch_Engine.cs` | MailKit transport + fetch loop. Scope selection (full / resume / date-range / uid-range / label), throttling, retries, checkpointing. |
| `Archive_Store.cs` | BYMONTH record writing, attachment ZIPs, manifest (crash-safe), `IArchiveContext`. |
| `Archive_Index.cs` | Lucene.NET index writer/searcher, field-scoped. |
| `Archive_Model.cs` | `Archive_Manifest`, `Archive_Record`, `Archive_Attachment`, `IArchiveContext`. |
| `Attachment_Text_Extractor.cs` | Text / PDF (PdfPig) / Word / Excel (OpenXml) extraction; images by name+size only. |
| `Plugin_Loader.cs` | Reflection discovery of `I_Run_Code_Against_Configuration`. |
| `I_Run_Code_Against_Configuration.cs` | Plugin contract. |
| `Email_Archiver.csproj` | Package references (MailKit, Lucene.NET, PdfPig, OpenXml, Newtonsoft, ProtectedData). |

## THREE INTEGRATION SEAMS — reconcile these with your existing code

I built this against the container/processor API surface from earlier turns. Three points
must line up. None are hard; each is a rename or a small addition.

### Seam 1 — `Process(byte[])` returns a container
`Gmail_Fetch_Engine.ProcessOne` calls:
```csharp
var msg = Gmail_IMAP_Message_Processors.Process(raw);   // returns Gmail_IMAP_Message_Container
```
This matches the static processor design we landed on (the one that returns a container).
If your final processor mutates a passed-in container instead, change the call to:
```csharp
var msg = new Gmail_IMAP_Message_Container();
Gmail_IMAP_Message_Processors.Process(msg, raw);
```

### Seam 2 — `ApplyImapMetadata` signature
I call it with named args:
```csharp
msg.ApplyImapMetadata(
    uid: ..., uidValidity: ..., rfc822Size: ..., internalDate: ...,
    flags: string[], gmMsgId: ulong, gmThrId: ulong, gmLabels: IEnumerable<string>);
```
Your container's `ApplyImapMetadata` from the earlier turn has exactly these parameters
EXCEPT it took `flags` as `IEnumerable<string>` — which matches. Confirm the `flags`
argument: MailKit exposes `summary.Flags` as `MessageFlags` (an enum), so I split its
`ToString()`. If you'd rather map the enum precisely, replace the `flags:` line with a
mapper (\Seen, \Flagged, \Answered, \Draft, \Deleted).

### Seam 3 — MIME part type (the important one)
`Archive_Store` iterates `msg.Parts` and expects each part to expose:
`FileName, ContentType, ContentId, IsAttachment, RawContent (byte[])`.

Your part type is `GmailMimePart` (renamed to avoid the MimeKit.MimePart collision).
It already has all five of those members. So do ONE of the following:

**Option A (recommended, zero code):** make `GmailMimePart` implement the marker interface:
```csharp
public sealed class GmailMimePart : Gmail_IMAP_MimePartLike { ... }  // members already satisfy it
```
Then change `Archive_Store.WriteAttachmentZip` param and the `.Where(...)` cast to `GmailMimePart`.

**Option B:** delete the `Gmail_IMAP_MimePartLike` interface and change
`WriteAttachmentZip(... List<GmailMimePart> parts ...)` and the `msg.Parts.Where(...)`
directly to `GmailMimePart`. Simplest if you don't want an extra interface.

I left the marker interface in so the store doesn't hard-depend on the exact part class
name, but either option compiles.

## Namespaces
- Engine types: `IVolt.Core.Email.Gmail`
- Plugin types: `IVolt.Core.Email.Gmail.Plugins`
- Config types: `IVolt.Core.Email.Configuration` (your existing container)

Make sure the container/processor from earlier live under `IVolt.Core.Email.Gmail` (or add
usings). Earlier turns used that namespace for the Gmail message types, so they should align.

## Package versions
Pinned in the `.csproj`. Lucene.NET 4.8.0-beta is the current stable line (beta in name only,
production-used for years). Bump to the latest beta build if a newer one is out.

## Windows-only
DPAPI config protection pins the app to Windows (`net8.0-windows`). Everything else
(MailKit, Lucene, extraction) is cross-platform; only config protection is the boundary.
