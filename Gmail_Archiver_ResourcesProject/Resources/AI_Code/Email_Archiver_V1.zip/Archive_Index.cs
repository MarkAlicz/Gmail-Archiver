using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

using Lucene.Net.Analysis.Standard;
using Lucene.Net.Documents;
using Lucene.Net.Index;
using Lucene.Net.QueryParsers.Classic;
using Lucene.Net.Search;
using Lucene.Net.Store;
using Lucene.Net.Util;
using LuceneDirectory = Lucene.Net.Store.Directory;

namespace IVolt.Core.Email.Gmail
{
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// Thin Lucene.NET wrapper for the local archive. One index per account under INDEX\{sanitized}\.
    /// Fields: pointer, gm_msgid, from, to, cc, bcc, subject, headers, body, att_names, att_content, date.
    /// Writing is incremental (one document per message, added during archival). Searching is field-scoped
    /// to back the search menu (senders / attachment names / attachment content / email text / headers).
    /// </summary>
    /// <remarks> I Volt, 6/30/2026. </remarks>
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    public sealed class Archive_Index : IDisposable
    {
        private const LuceneVersion Version = LuceneVersion.LUCENE_48;

        public const string F_POINTER      = "pointer";
        public const string F_GM_MSGID     = "gm_msgid";
        public const string F_FROM         = "from";
        public const string F_TO           = "to";
        public const string F_CC           = "cc";
        public const string F_BCC          = "bcc";
        public const string F_SUBJECT      = "subject";
        public const string F_HEADERS      = "headers";
        public const string F_BODY         = "body";
        public const string F_ATT_NAMES    = "att_names";
        public const string F_ATT_CONTENT  = "att_content";
        public const string F_DATE         = "date";      // yyyyMMdd for range queries

        private readonly string _indexPath;
        private readonly StandardAnalyzer _analyzer;
        private LuceneDirectory _dir;
        private IndexWriter _writer;

        public Archive_Index(string indexFolder)
        {
            _indexPath = indexFolder;
            System.IO.Directory.CreateDirectory(_indexPath);
            _analyzer = new StandardAnalyzer(Version);
            _dir = FSDirectory.Open(_indexPath);
        }

        // ---- Writing ------------------------------------------------------
        public void OpenForWrite()
        {
            if (_writer != null) return;
            var cfg = new IndexWriterConfig(Version, _analyzer)
            {
                OpenMode = OpenMode.CREATE_OR_APPEND
            };
            _writer = new IndexWriter(_dir, cfg);
        }

        /// <summary>Adds (or replaces, keyed by gm_msgid) one message document.</summary>
        public void AddOrUpdate(Archive_Record rec, string attachmentContent)
        {
            OpenForWrite();
            var doc = new Document
            {
                new StringField(F_POINTER, rec.archive_pointer.ToString(), Field.Store.YES),
                new StringField(F_GM_MSGID, rec.gm_msgid ?? string.Empty, Field.Store.YES),
                new TextField(F_FROM, rec.from ?? string.Empty, Field.Store.YES),
                new TextField(F_TO, string.Join(" ", rec.to ?? new List<string>()), Field.Store.NO),
                new TextField(F_CC, string.Join(" ", rec.cc ?? new List<string>()), Field.Store.NO),
                new TextField(F_BCC, string.Join(" ", rec.bcc ?? new List<string>()), Field.Store.NO),
                new TextField(F_SUBJECT, rec.subject ?? string.Empty, Field.Store.YES),
                new TextField(F_HEADERS, FlattenHeaders(rec), Field.Store.NO),
                new TextField(F_BODY, rec.text_body ?? string.Empty, Field.Store.NO),
                new TextField(F_ATT_NAMES,
                    string.Join(" ", (rec.attachments ?? new List<Archive_Attachment>()).Select(a => a.file_name)),
                    Field.Store.YES),
                new TextField(F_ATT_CONTENT, attachmentContent ?? string.Empty, Field.Store.NO),
                new StringField(F_DATE, ToDateKey(rec.date), Field.Store.YES),
            };

            // Replace any existing doc for this gm_msgid so re-runs are idempotent.
            if (!string.IsNullOrEmpty(rec.gm_msgid))
                _writer.UpdateDocument(new Term(F_GM_MSGID, rec.gm_msgid), doc);
            else
                _writer.AddDocument(doc);
        }

        public void Commit() => _writer?.Commit();

        // ---- Searching ----------------------------------------------------
        /// <summary>Field-scoped search. Returns matching archive pointers, most relevant first.</summary>
        public List<long> Search(string field, string queryText, int maxResults = 200)
        {
            _writer?.Commit();
            using var reader = DirectoryReader.Open(_dir);
            var searcher = new IndexSearcher(reader);
            var parser = new QueryParser(Version, field, _analyzer);
            parser.AllowLeadingWildcard = true;

            Query query;
            try { query = parser.Parse(queryText); }
            catch (ParseException) { query = new TermQuery(new Term(field, queryText.ToLowerInvariant())); }

            var hits = searcher.Search(query, maxResults).ScoreDocs;
            var results = new List<long>(hits.Length);
            foreach (var h in hits)
            {
                var doc = searcher.Doc(h.Doc);
                if (long.TryParse(doc.Get(F_POINTER), out long ptr))
                    results.Add(ptr);
            }
            return results;
        }

        public int DocumentCount()
        {
            try
            {
                using var reader = DirectoryReader.Open(_dir);
                return reader.NumDocs;
            }
            catch { return 0; }
        }

        private static string FlattenHeaders(Archive_Record rec)
        {
            if (rec.headers == null) return string.Empty;
            return string.Join(" ", rec.headers.Select(h => h.Key + " " + h.Value));
        }

        private static string ToDateKey(string iso)
        {
            if (DateTimeOffset.TryParse(iso, out var d)) return d.ToString("yyyyMMdd");
            return string.Empty;
        }

        public void Dispose()
        {
            _writer?.Dispose();
            _dir?.Dispose();
            _analyzer?.Dispose();
        }
    }
}
