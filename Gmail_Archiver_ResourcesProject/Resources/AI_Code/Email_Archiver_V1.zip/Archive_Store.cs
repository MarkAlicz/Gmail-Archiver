using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;

using IVolt.Core.Email.Configuration;

namespace IVolt.Core.Email.Gmail
{
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// Owns the on-disk local archive for one account: BYMONTH record writing, per-message attachment
    /// ZIPs, the Lucene index, and the crash-safe manifest. Implements IArchiveContext for search/plugins.
    /// All paths derive from the loaded configuration.
    /// </summary>
    /// <remarks> I Volt, 6/30/2026. </remarks>
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    public sealed class Archive_Store : IArchiveContext, IDisposable
    {
        private readonly Configuration_Definition_Container _cfg;
        private readonly string _manifestPath;

        public string AccountKey { get; }
        public string ArchiveFolder { get; }
        public string AttachmentsFolder { get; }
        public string IndexFolder { get; }
        public Archive_Manifest Manifest { get; private set; }
        public Archive_Index Index { get; }

        public Archive_Store(Configuration_Definition_Container cfg)
        {
            _cfg = cfg ?? throw new ArgumentNullException(nameof(cfg));
            AccountKey = Gmail_IMAP_Management_Class.SanitizeEmail(cfg.email);

            ArchiveFolder     = cfg.archive_folder             ?? throw new InvalidOperationException("archive_folder not set.");
            AttachmentsFolder = cfg.archive_attachments_folder ?? Path.Combine(ArchiveFolder, "ATTACHMENTS");
            IndexFolder       = cfg.archive_index_folder       ?? throw new InvalidOperationException("archive_index_folder not set.");

            System.IO.Directory.CreateDirectory(ArchiveFolder);
            System.IO.Directory.CreateDirectory(AttachmentsFolder);
            System.IO.Directory.CreateDirectory(IndexFolder);

            _manifestPath = Path.Combine(ArchiveFolder, AccountKey + ".manifest.json");
            Manifest = LoadOrCreateManifest();
            Index = new Archive_Index(IndexFolder);
        }

        // ---- Manifest -----------------------------------------------------
        private Archive_Manifest LoadOrCreateManifest()
        {
            if (File.Exists(_manifestPath))
            {
                try { return Archive_Manifest.FromJson(File.ReadAllText(_manifestPath)); }
                catch { /* fall through to fresh */ }
            }
            return new Archive_Manifest
            {
                account_key = AccountKey,
                email = _cfg.email,
                next_pointer = _cfg.archive_pointer_starting_increment ?? 1212,
            };
        }

        /// <summary>Atomic manifest write (temp + replace) so a crash never corrupts it.</summary>
        public void SaveManifest()
        {
            Manifest.last_run_utc = DateTimeOffset.UtcNow.ToString("o");
            string tmp = _manifestPath + ".tmp";
            File.WriteAllText(tmp, Manifest.ToJson());
            if (File.Exists(_manifestPath)) File.Replace(tmp, _manifestPath, null);
            else File.Move(tmp, _manifestPath);
        }

        public bool AlreadyArchived(string gmMsgId) =>
            !string.IsNullOrEmpty(gmMsgId) && Manifest.seen.ContainsKey(gmMsgId);

        // ---- Storing a message -------------------------------------------
        /// <summary>
        /// Persists one parsed message: writes the BYMONTH JSON record, zips attachments (honoring config),
        /// indexes enabled fields, updates the manifest. Returns the assigned archive pointer.
        /// </summary>
        public long StoreMessage(Gmail_IMAP_Message_Container msg)
        {
            long pointer = Manifest.next_pointer;

            // BYMONTH bucket from message date (fallback: internal date, then 'unknown').
            var (year, month) = BucketFor(msg);
            string relDir = Path.Combine(year, month);
            string absDir = Path.Combine(ArchiveFolder, relDir);
            System.IO.Directory.CreateDirectory(absDir);

            var rec = BuildRecord(msg, pointer);
            rec.record_path = Path.Combine(relDir, pointer + ".json");

            // Attachments -> per-message ZIP (if enabled), collecting extracted text for the index.
            string attachmentText = null;
            if ((_cfg.archive_attachments ?? true) && msg.Parts != null)
            {
                var attParts = msg.Parts.Where(p => p.IsAttachment ||
                                                    !string.IsNullOrEmpty(p.FileName)).ToList();
                if (attParts.Count > 0)
                {
                    string zipRel = Path.Combine(AttachmentsFolderRel(), pointer + ".zip");
                    string zipAbs = AttachmentZipPath(pointer);
                    attachmentText = WriteAttachmentZip(zipAbs, attParts, rec);
                    rec.attachment_zip = zipRel;
                    Manifest.attachment_count += attParts.Count;
                }
            }

            // Write the record JSON.
            File.WriteAllText(Path.Combine(ArchiveFolder, rec.record_path), rec.ToJson());

            // Index (respect per-field switches by blanking disabled fields).
            IndexRecord(rec, attachmentText);

            // Manifest updates.
            if (!string.IsNullOrEmpty(rec.gm_msgid))
                Manifest.seen[rec.gm_msgid] = pointer;
            Manifest.message_count += 1;
            Manifest.next_pointer = pointer + 1;
            UpdateDateRange(rec.date);

            return pointer;
        }

        private void IndexRecord(Archive_Record rec, string attachmentText)
        {
            // Clone-with-blanks per configuration index switches, then index.
            var indexed = new Archive_Record
            {
                archive_pointer = rec.archive_pointer,
                gm_msgid = rec.gm_msgid,
                date = rec.date,
                subject   = (_cfg.index_email_subject ?? true) ? rec.subject : null,
                from      = (_cfg.index_email_from ?? true) ? rec.from : null,
                to        = (_cfg.index_email_to ?? true) ? rec.to : new List<string>(),
                cc        = (_cfg.index_email_cc ?? true) ? rec.cc : new List<string>(),
                bcc       = (_cfg.index_email_bcc ?? true) ? rec.bcc : new List<string>(),
                text_body = (_cfg.index_email_body ?? true) ? rec.text_body : null,
                headers   = rec.headers,
                attachments = (_cfg.index_email_attachments ?? true) ? rec.attachments : new List<Archive_Attachment>(),
            };
            string attText = (_cfg.index_email_attachments ?? true) ? attachmentText : null;
            Index.AddOrUpdate(indexed, attText);
        }

        private (string year, string month) BucketFor(Gmail_IMAP_Message_Container msg)
        {
            DateTimeOffset? d = msg.Date ?? msg.InternalDate;
            if (d.HasValue) return (d.Value.Year.ToString("D4"), d.Value.Month.ToString("D2"));
            return ("unknown", "unknown");
        }

        private string AttachmentsFolderRel()
        {
            // Attachments folder may be outside ArchiveFolder; store an absolute-safe relative token.
            return "..\\ATTACHMENTS";
        }

        public string AttachmentZipPath(long archivePointer) =>
            Path.Combine(AttachmentsFolder, archivePointer + ".zip");

        private string WriteAttachmentZip(string zipPath, List<Gmail_IMAP_MimePartLike> parts, Archive_Record rec)
        {
            var sb = new StringBuilder();
            using (var fs = new FileStream(zipPath, FileMode.Create))
            using (var zip = new ZipArchive(fs, ZipArchiveMode.Create))
            {
                int n = 0;
                foreach (var p in parts)
                {
                    n++;
                    string safeName = MakeSafeName(p.FileName, n, p.ContentType);
                    var entry = zip.CreateEntry(safeName, CompressionLevel.Optimal);
                    using (var es = entry.Open())
                        es.Write(p.RawContent, 0, p.RawContent.Length);

                    string extracted = Attachment_Text_Extractor.Extract(safeName, p.ContentType, p.RawContent);
                    bool indexed = !string.IsNullOrEmpty(extracted);
                    if (indexed) sb.Append(extracted).Append('\n');

                    rec.attachments.Add(new Archive_Attachment
                    {
                        file_name = p.FileName,
                        content_type = p.ContentType,
                        content_id = p.ContentId,
                        size_bytes = p.RawContent?.LongLength ?? 0,
                        zip_entry = safeName,
                        content_indexed = indexed
                    });
                }
            }
            return sb.ToString();
        }

        private static string MakeSafeName(string name, int ordinal, string contentType)
        {
            if (string.IsNullOrWhiteSpace(name))
                name = "attachment_" + ordinal + GuessExt(contentType);
            foreach (char c in Path.GetInvalidFileNameChars())
                name = name.Replace(c, '_');
            return ordinal.ToString("D3") + "_" + name;
        }

        private static string GuessExt(string ct)
        {
            ct = (ct ?? "").ToLowerInvariant();
            if (ct.Contains("pdf")) return ".pdf";
            if (ct.Contains("png")) return ".png";
            if (ct.Contains("jpeg") || ct.Contains("jpg")) return ".jpg";
            if (ct.StartsWith("text/")) return ".txt";
            return ".bin";
        }

        private void UpdateDateRange(string iso)
        {
            if (!DateTimeOffset.TryParse(iso, out var d)) return;
            if (string.IsNullOrEmpty(Manifest.earliest_date) ||
                (DateTimeOffset.TryParse(Manifest.earliest_date, out var e) && d < e))
                Manifest.earliest_date = iso;
            if (string.IsNullOrEmpty(Manifest.latest_date) ||
                (DateTimeOffset.TryParse(Manifest.latest_date, out var l) && d > l))
                Manifest.latest_date = iso;
        }

        private Archive_Record BuildRecord(Gmail_IMAP_Message_Container m, long pointer)
        {
            return new Archive_Record
            {
                archive_pointer = pointer,
                gm_msgid = m.GmMsgId != 0 ? m.GmMsgId.ToString() : null,
                gm_thrid = m.GmThrId != 0 ? m.GmThrId.ToString() : null,
                gm_labels = m.GmLabels != null ? new List<string>(m.GmLabels) : new List<string>(),
                uid = m.Uid,
                raw_sha256 = m.RawSha256,
                message_id = m.MessageId,
                date = m.Date?.ToString("o"),
                internal_date = m.InternalDate?.ToString("o"),
                subject = m.Subject,
                from = m.From?.ToString(),
                to = m.To?.Select(a => a.ToString()).ToList() ?? new List<string>(),
                cc = m.Cc?.Select(a => a.ToString()).ToList() ?? new List<string>(),
                bcc = m.Bcc?.Select(a => a.ToString()).ToList() ?? new List<string>(),
                headers = m.Headers ?? new List<KeyValuePair<string, string>>(),
                text_body = m.TextBody,
                html_body = m.HtmlBody,
            };
        }

        // ---- IArchiveContext read surface --------------------------------
        public IEnumerable<Archive_Record> EnumerateRecords()
        {
            if (!System.IO.Directory.Exists(ArchiveFolder)) yield break;
            foreach (var file in System.IO.Directory.EnumerateFiles(ArchiveFolder, "*.json", SearchOption.AllDirectories))
            {
                if (file.EndsWith(".manifest.json", StringComparison.OrdinalIgnoreCase)) continue;
                Archive_Record rec = null;
                try { rec = Archive_Record.FromJson(File.ReadAllText(file)); } catch { }
                if (rec != null) yield return rec;
            }
        }

        public Archive_Record LoadRecord(long pointer)
        {
            return EnumerateRecords().FirstOrDefault(r => r.archive_pointer == pointer);
        }

        // ---- Manifest rebuild (self-healing fallback) --------------------
        public void RebuildManifestFromTree()
        {
            var fresh = new Archive_Manifest
            {
                account_key = AccountKey,
                email = _cfg.email,
                next_pointer = _cfg.archive_pointer_starting_increment ?? 1212,
            };
            long maxPtr = fresh.next_pointer - 1;
            foreach (var rec in EnumerateRecords())
            {
                if (!string.IsNullOrEmpty(rec.gm_msgid))
                    fresh.seen[rec.gm_msgid] = rec.archive_pointer;
                fresh.message_count++;
                fresh.attachment_count += rec.attachments?.Count ?? 0;
                if (rec.archive_pointer > maxPtr) maxPtr = rec.archive_pointer;
                UpdateRange(fresh, rec.date);
            }
            fresh.next_pointer = maxPtr + 1;
            Manifest = fresh;
            SaveManifest();
        }

        private static void UpdateRange(Archive_Manifest man, string iso)
        {
            if (!DateTimeOffset.TryParse(iso, out var d)) return;
            if (string.IsNullOrEmpty(man.earliest_date) ||
                (DateTimeOffset.TryParse(man.earliest_date, out var e) && d < e))
                man.earliest_date = iso;
            if (string.IsNullOrEmpty(man.latest_date) ||
                (DateTimeOffset.TryParse(man.latest_date, out var l) && d > l))
                man.latest_date = iso;
        }

        public void Dispose()
        {
            Index?.Commit();
            Index?.Dispose();
        }
    }

    /// <summary>
    /// Minimal shape the store needs from a MIME part. Your Gmail_IMAP_MimePart (or GmailMimePart)
    /// should satisfy this; adapt the property names if yours differ.
    /// </summary>
    public interface Gmail_IMAP_MimePartLike
    {
        string FileName { get; }
        string ContentType { get; }
        string ContentId { get; }
        bool IsAttachment { get; }
        byte[] RawContent { get; }
    }
}
