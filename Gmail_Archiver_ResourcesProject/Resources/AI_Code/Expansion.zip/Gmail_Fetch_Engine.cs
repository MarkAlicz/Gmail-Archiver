using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Threading;

using MailKit;
using MailKit.Net.Imap;
using MailKit.Search;
using MailKit.Security;

using IVolt.Core.Email.Configuration;

namespace IVolt.Core.Email.Gmail
{
    /// <summary>Scope of a fetch run, chosen by the operator before processing.</summary>
    public enum Fetch_Scope
    {
        FullExtract,     // everything in the folder
        Resume,          // everything, but manifest dedup skips already-archived
        DateRange,       // messages within [Since, Before]
        UidRange,        // messages with UID above the stored high-water mark
        Label            // a specific Gmail label / folder
    }

    public sealed class Fetch_Options
    {
        public Fetch_Scope Scope { get; set; } = Fetch_Scope.Resume;
        public DateTime? Since { get; set; }
        public DateTime? Before { get; set; }
        public string Label { get; set; } = "[Gmail]/All Mail";
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// Archival fetch loop over MailKit transport. MailKit fetches raw octets (BODY.PEEK[]) plus native
    /// X-GM-* metadata; the custom Gmail_IMAP_Message_Processors performs all parsing and the SHA-256
    /// provenance hash. Honors every performance setting. Parse failures NEVER lose a message — they are
    /// archived raw with metadata; only genuine transport failures are retried and, on give-up, logged
    /// for later retry via the menu subsystem.
    /// </summary>
    /// <remarks> I Volt, 6/30/2026. </remarks>
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    public sealed class Gmail_Fetch_Engine
    {
        private readonly Configuration_Definition_Container _cfg;
        private readonly Archive_Store _store;
        private readonly TextWriter _out;

        // Throttle accounting (rolling one-minute window).
        private int _emailsThisMinute;
        private long _bytesThisMinute;
        private DateTime _windowStart = DateTime.UtcNow;

        public Gmail_Fetch_Engine(Configuration_Definition_Container cfg, Archive_Store store, TextWriter output)
        {
            _cfg = cfg;
            _store = store;
            _out = output;
        }

        /// <summary>Opens a connected, authenticated IMAP client. Caller disposes.</summary>
        public ImapClient Connect()
        {
            var client = new ImapClient();
            string host = _cfg.server?.imap ?? "imap.gmail.com";
            int port = (int)(_cfg.server?.port ?? 993);
            bool ssl = _cfg.server?.ssl ?? true;

            client.Connect(host, port, ssl ? SecureSocketOptions.SslOnConnect : SecureSocketOptions.StartTls);

            string user = _cfg.email;
            string pass = _cfg.server?.application_specific_password ?? _cfg.password;
            client.Authenticate(user, pass);
            return client;
        }

        /// <summary>Runs the archival loop for the given options. Returns count of newly archived messages.</summary>
        public long Run(Fetch_Options opts)
        {
            long archived = 0;
            var failures = new Failure_Log(_store.ArchiveFolder, _store.AccountKey);

            using var client = Connect();

            var folder = client.GetFolder(opts.Label);
            folder.Open(FolderAccess.ReadOnly);
            _out.WriteLine($"Opened '{opts.Label}': {folder.Count} messages, UIDVALIDITY {folder.UidValidity}.");

            IList<UniqueId> uids = SelectUids(folder, opts);
            _out.WriteLine($"Scope '{opts.Scope}' selected {uids.Count} candidate message(s).");

            int maxRetries = (int)(_cfg.performance?.max_retries ?? 3);

            foreach (var uid in uids)
            {
                // Cheap metadata fetch first, so duplicates skip before pulling the body.
                IMessageSummary summary;
                try
                {
                    summary = folder.Fetch(new[] { uid },
                        MessageSummaryItems.UniqueId |
                        MessageSummaryItems.Flags |
                        MessageSummaryItems.InternalDate |
                        MessageSummaryItems.Size |
                        MessageSummaryItems.GMailMessageId |
                        MessageSummaryItems.GMailThreadId |
                        MessageSummaryItems.GMailLabels).FirstOrDefault();
                }
                catch (Exception ex)
                {
                    _out.WriteLine($"  ! Fetch summary failed for UID {uid}: {ex.Message}");
                    failures.Record(uid.Id, folder.UidValidity, opts.Label, "summary fetch failed: " + ex.Message);
                    continue;
                }
                if (summary == null) continue;

                string gmId = summary.GMailMessageId?.ToString();
                if (_store.AlreadyArchived(gmId))
                    continue; // dedup

                bool ok = false;
                for (int attempt = 1; attempt <= maxRetries && !ok; attempt++)
                {
                    try
                    {
                        ProcessOne(folder, uid, summary);  // parse errors handled internally
                        archived++;
                        ok = true;
                    }
                    catch (Exception ex)
                    {
                        // Only genuine transport/store failures reach here now.
                        _out.WriteLine($"  ! Attempt {attempt}/{maxRetries} failed for UID {uid}: {ex.Message}");
                        if (attempt == maxRetries)
                        {
                            _out.WriteLine($"  x Giving up on UID {uid} after {maxRetries} attempts.");
                            failures.Record(summary.UniqueId.Id, folder.UidValidity, opts.Label,
                                            "max retries exceeded: " + ex.Message);
                        }
                        else
                        {
                            Thread.Sleep(1000 * attempt); // simple backoff
                        }
                    }
                }

                // Periodic checkpoint so an interrupt loses little.
                if (ok && archived % 25 == 0)
                {
                    _store.Index.Commit();
                    if (summary.UniqueId.Id > _store.Manifest.high_water_uid)
                    {
                        _store.Manifest.high_water_uid = summary.UniqueId.Id;
                        _store.Manifest.uid_validity = folder.UidValidity;
                    }
                    _store.SaveManifest();
                    _out.WriteLine($"  … {archived} archived (checkpoint).");
                }

                Throttle(summary.Size ?? 0);
            }

            // Final flush.
            _store.Index.Commit();
            if (uids.Count > 0)
            {
                uint maxUid = uids.Max(u => u.Id);
                if (maxUid > _store.Manifest.high_water_uid)
                {
                    _store.Manifest.high_water_uid = maxUid;
                    _store.Manifest.uid_validity = folder.UidValidity;
                }
            }
            _store.SaveManifest();

            folder.Close();
            client.Disconnect(true);
            _out.WriteLine($"Run complete. Newly archived: {archived}.");
            return archived;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// Re-fetches and re-processes a single message by UID. Used by the "Retry Errors Found in Logs"
        /// menu item. Ignores the dedup set (a retry is an explicit reprocess request). Returns true if the
        /// message was archived; false if it no longer exists in the folder.
        /// </summary>
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        public bool RetryOne(IMailFolder folder, UniqueId uid)
        {
            var summary = folder.Fetch(new[] { uid },
                MessageSummaryItems.UniqueId |
                MessageSummaryItems.Flags |
                MessageSummaryItems.InternalDate |
                MessageSummaryItems.Size |
                MessageSummaryItems.GMailMessageId |
                MessageSummaryItems.GMailThreadId |
                MessageSummaryItems.GMailLabels).FirstOrDefault();

            if (summary == null) return false; // moved/deleted since the failure was logged

            ProcessOne(folder, uid, summary);
            return true;
        }

        // ---- Single-message processing (defensive) -----------------------
        private void ProcessOne(IMailFolder folder, UniqueId uid, IMessageSummary summary)
        {
            // Pull exact wire octets without marking \Seen — provenance-preserving.
            byte[] raw;
            using (var stream = folder.GetStream(uid, string.Empty, 0, int.MaxValue))
            using (var ms = new MemoryStream())
            {
                stream.CopyTo(ms);
                raw = ms.ToArray();
            }

            Gmail_IMAP_Message_Container msg;
            try
            {
                // Custom parser owns SHA-256 + MIME decode.
                msg = Gmail_IMAP_Message_Processors.Process(raw);
            }
            catch (Exception ex)
            {
                // Catch-all: a malformed header must not lose the message. We still hold the
                // raw octets and can hash them; archive a minimal record with metadata only.
                _out.WriteLine($"    (parse degraded for UID {uid}: {ex.Message}; archiving raw)");
                msg = BuildMinimalContainer(raw);
            }

            // Metadata is independent of body parsing — always safe to apply.
            ApplyMetadata(msg, folder, summary);

            _store.StoreMessage(msg);
        }

        /// <summary>Minimal container when full parse fails: raw bytes + hash, metadata applied later.</summary>
        private static Gmail_IMAP_Message_Container BuildMinimalContainer(byte[] raw)
        {
            var c = new Gmail_IMAP_Message_Container
            {
                RawBytes = raw,
                RawSha256 = Convert.ToHexString(SHA256.HashData(raw)).ToLowerInvariant(),
            };
            c.ParseWarnings.Add("Full parse failed; archived as raw with metadata only.");
            return c;
        }

        /// <summary>Applies IMAP-layer + Gmail metadata from the MailKit summary to the container.</summary>
        private static void ApplyMetadata(Gmail_IMAP_Message_Container msg, IMailFolder folder, IMessageSummary summary)
        {
            msg.Uid          = summary.UniqueId.Id;
            msg.UidValidity  = folder.UidValidity;
            msg.Rfc822Size   = summary.Size ?? 0;
            msg.InternalDate = summary.InternalDate;
            msg.GmMsgId      = summary.GMailMessageId ?? 0;
            msg.GmThrId      = summary.GMailThreadId ?? 0;

            if (summary.GMailLabels != null)
                foreach (var label in summary.GMailLabels)
                    msg.GmLabels.Add(label);

            if (summary.Flags.HasValue)
            {
                var f = summary.Flags.Value;
                if (f.HasFlag(MessageFlags.Seen))     msg.Flags.Add("\\Seen");
                if (f.HasFlag(MessageFlags.Answered)) msg.Flags.Add("\\Answered");
                if (f.HasFlag(MessageFlags.Flagged))  msg.Flags.Add("\\Flagged");
                if (f.HasFlag(MessageFlags.Deleted))  msg.Flags.Add("\\Deleted");
                if (f.HasFlag(MessageFlags.Draft))    msg.Flags.Add("\\Draft");
            }
        }

        // ---- Scope -> UID set --------------------------------------------
        private IList<UniqueId> SelectUids(IMailFolder folder, Fetch_Options opts)
        {
            switch (opts.Scope)
            {
                case Fetch_Scope.DateRange:
                    var q = SearchQuery.All;
                    if (opts.Since.HasValue) q = q.And(SearchQuery.DeliveredAfter(opts.Since.Value));
                    if (opts.Before.HasValue) q = q.And(SearchQuery.DeliveredBefore(opts.Before.Value));
                    return folder.Search(q);

                case Fetch_Scope.UidRange:
                    uint hw = _store.Manifest.high_water_uid;
                    if (folder.UidValidity != _store.Manifest.uid_validity) hw = 0; // validity changed -> full
                    var range = new UniqueIdRange(new UniqueId(folder.UidValidity, hw + 1), UniqueId.MaxValue);
                    return folder.Search(SearchQuery.Uids(range));

                case Fetch_Scope.FullExtract:
                case Fetch_Scope.Resume:
                case Fetch_Scope.Label:
                default:
                    return folder.Search(SearchQuery.All); // Resume dedups later via manifest
            }
        }

        // ---- Throttling ---------------------------------------------------
        private void Throttle(long messageBytes)
        {
            int maxEmails = (int)(_cfg.performance?.max_emails_per_minute ?? 100);
            long maxAttMB = _cfg.performance?.max_attachment_size_in_MB_per_minute ?? 50;
            int pauseSec  = (int)(_cfg.performance?.pause_between_requests_in_seconds ?? 11);

            // Roll the window if a full minute has elapsed.
            if ((DateTime.UtcNow - _windowStart).TotalSeconds >= 60)
            {
                _windowStart = DateTime.UtcNow;
                _emailsThisMinute = 0;
                _bytesThisMinute = 0;
            }

            _emailsThisMinute++;
            _bytesThisMinute += messageBytes;

            bool overEmail = _emailsThisMinute >= maxEmails;
            bool overBytes = _bytesThisMinute >= maxAttMB * 1024L * 1024L;
            if (overEmail || overBytes)
            {
                double wait = 60 - (DateTime.UtcNow - _windowStart).TotalSeconds;
                if (wait > 0)
                {
                    _out.WriteLine($"  \u29D7 Rate ceiling reached; pausing {wait:F0}s.");
                    Thread.Sleep(TimeSpan.FromSeconds(wait));
                }
                _windowStart = DateTime.UtcNow;
                _emailsThisMinute = 0;
                _bytesThisMinute = 0;
            }

            if (pauseSec > 0) Thread.Sleep(TimeSpan.FromSeconds(pauseSec));
        }
    }
}
