using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

using MailKit;
using MailKit.Net.Imap;

using Newtonsoft.Json;

using IVolt.Core.Email.Configuration;

namespace IVolt.Core.Email.Gmail
{
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// Lightweight, extensible console menu framework. Register items with a label and an action;
    /// the menu renders them, reads the choice, and loops until Back/Exit. Items may be conditionally
    /// visible. Add new capabilities by calling Add(...) — no changes to the loop itself.
    ///
    /// Usage:
    ///   var m = new Menu("OPERATIONS");
    ///   m.Add("Edit Configuration", () => Archive_Operations.EditConfiguration());
    ///   m.Add("Retry Logged Errors", () => Archive_Operations.RetryLoggedErrors(cfg, store));
    ///   m.Show();
    /// </summary>
    /// <remarks> I Volt, 6/30/2026. </remarks>
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    public sealed class Menu
    {
        private readonly List<Menu_Item> _items = new List<Menu_Item>();
        private readonly TextWriter _out;
        private readonly TextReader _in;

        public string Title { get; set; }
        public string BackLabel { get; set; } = "Back";

        public Menu(string title, TextWriter output = null, TextReader input = null)
        {
            Title = title;
            _out = output ?? Console.Out;
            _in = input ?? Console.In;
        }

        /// <summary>Register a menu item. Returns this for fluent chaining.</summary>
        public Menu Add(string label, Action action, Func<bool> visible = null)
        {
            _items.Add(new Menu_Item { Label = label, Action = action, Visible = visible });
            return this;
        }

        /// <summary>Register an item whose action reports success/failure for a status line.</summary>
        public Menu Add(string label, Func<bool> action, Func<bool> visible = null)
        {
            _items.Add(new Menu_Item
            {
                Label = label,
                Action = () =>
                {
                    bool ok = action();
                    _out.WriteLine(ok ? "  ✓ Done." : "  ! Completed with issues.");
                },
                Visible = visible
            });
            return this;
        }

        /// <summary>Renders the menu and processes input until the user chooses Back/Exit (0).</summary>
        public void Show()
        {
            while (true)
            {
                var visible = _items.Where(i => i.Visible == null || i.Visible()).ToList();

                _out.WriteLine();
                _out.WriteLine($"  ===== {Title} =====");
                for (int i = 0; i < visible.Count; i++)
                    _out.WriteLine($"  {i + 1}. {visible[i].Label}");
                _out.WriteLine($"  0. {BackLabel}");
                _out.Write("  Choose: ");

                string raw = (_in.ReadLine() ?? string.Empty).Trim();
                if (raw == "0") return;

                if (!int.TryParse(raw, out int sel) || sel < 1 || sel > visible.Count)
                {
                    _out.WriteLine("  Unrecognized option.");
                    continue;
                }

                try
                {
                    visible[sel - 1].Action();
                }
                catch (Exception ex)
                {
                    _out.WriteLine($"  ✗ '{visible[sel - 1].Label}' failed: {ex.Message}");
                }
            }
        }
    }

    /// <summary>A single registered menu entry.</summary>
    public sealed class Menu_Item
    {
        public string Label { get; set; }
        public Action Action { get; set; }
        /// <summary>Optional predicate; when it returns false the item is hidden.</summary>
        public Func<bool> Visible { get; set; }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// Persistent per-account record of messages that failed to archive. Written by the fetch loop when
    /// it gives up on a UID, read by the "Retry Logged Errors" menu item. Stored as JSON lines next to
    /// the archive so it survives restarts and is human-inspectable.
    /// </summary>
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    public sealed class Failure_Log
    {
        public sealed class Entry
        {
            [JsonProperty("uid")]           public uint uid { get; set; }
            [JsonProperty("uid_validity")]  public uint uid_validity { get; set; }
            [JsonProperty("folder")]        public string folder { get; set; }
            [JsonProperty("reason")]        public string reason { get; set; }
            [JsonProperty("utc")]           public string utc { get; set; }
            [JsonProperty("resolved")]      public bool resolved { get; set; }
        }

        private readonly string _path;

        public Failure_Log(string archiveFolder, string accountKey)
        {
            _path = Path.Combine(archiveFolder, accountKey + ".failures.log");
        }

        public string Path => _path;

        /// <summary>Append a failure. Called by the fetch loop's give-up branch.</summary>
        public void Record(uint uid, uint uidValidity, string folder, string reason)
        {
            var e = new Entry
            {
                uid = uid,
                uid_validity = uidValidity,
                folder = folder,
                reason = reason,
                utc = DateTimeOffset.UtcNow.ToString("o"),
                resolved = false
            };
            File.AppendAllText(_path, JsonConvert.SerializeObject(e) + Environment.NewLine);
        }

        /// <summary>Reads all entries (one JSON object per line). Tolerant of blank/garbled lines.</summary>
        public List<Entry> ReadAll()
        {
            var list = new List<Entry>();
            if (!File.Exists(_path)) return list;
            foreach (var line in File.ReadAllLines(_path))
            {
                if (string.IsNullOrWhiteSpace(line)) continue;
                try { var e = JsonConvert.DeserializeObject<Entry>(line); if (e != null) list.Add(e); }
                catch { /* skip unparseable line */ }
            }
            return list;
        }

        /// <summary>Distinct unresolved UIDs, most recent reason kept.</summary>
        public List<Entry> UnresolvedDistinct()
        {
            return ReadAll()
                .Where(e => !e.resolved)
                .GroupBy(e => e.uid)
                .Select(g => g.Last())
                .OrderBy(e => e.uid)
                .ToList();
        }

        /// <summary>Rewrites the log marking the given UIDs resolved.</summary>
        public void MarkResolved(IEnumerable<uint> uids)
        {
            var set = new HashSet<uint>(uids);
            var all = ReadAll();
            foreach (var e in all) if (set.Contains(e.uid)) e.resolved = true;
            using var w = new StreamWriter(_path, false);
            foreach (var e in all) w.WriteLine(JsonConvert.SerializeObject(e));
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// The two fully-coded operations exposed through the menu subsystem:
    ///   (1) Edit a configuration file — DPAPI-load, field-by-field edit, DPAPI-save.
    ///   (2) Retry logged errors — re-fetch and re-process every unresolved UID from the failure log.
    /// Wire these into any Menu via Add(...). More items can be added the same way.
    /// </summary>
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    public static class Archive_Operations
    {
        private static readonly TextWriter Out = Console.Out;

        // Convenience: build the operations submenu with both items registered.
        public static Menu BuildMenu(Configuration_Definition_Container cfg, Archive_Store store)
        {
            var menu = new Menu("OPERATIONS");
            menu.Add("Edit Configuration File", () => EditConfiguration(cfg?.email));
            menu.Add("Retry Errors Found in Logs", () => RetryLoggedErrors(cfg, store));
            return menu;
        }

        // =====================================================================
        // ITEM 1 — Edit configuration file
        // =====================================================================
        /// <summary>
        /// Loads a DPAPI-protected configuration, lets the operator edit common fields one at a time,
        /// and re-saves it protected. Secrets are shown masked. If no email is supplied, prompts for one.
        /// </summary>
        public static void EditConfiguration(string email = null)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                Out.Write("  Email of the configuration to edit: ");
                email = (Console.ReadLine() ?? string.Empty).Trim();
                if (string.IsNullOrWhiteSpace(email)) { Out.WriteLine("  Cancelled."); return; }
            }

            string path = Gmail_IMAP_Management_Class.PathFor(email);
            if (!File.Exists(path))
            {
                Out.WriteLine($"  No configuration found at: {path}");
                return;
            }

            Configuration_Definition_Container cfg;
            try
            {
                cfg = Configuration_Definition_Container.FromJson(
                    Gmail_IMAP_Management_Class.UnprotectFile(path));
            }
            catch (Exception ex)
            {
                Out.WriteLine($"  Could not open/decrypt configuration: {ex.Message}");
                return;
            }

            bool dirty = false;
            while (true)
            {
                Out.WriteLine();
                Out.WriteLine($"  ===== EDIT: {cfg.email} =====");
                Out.WriteLine($"   1. Email                         : {cfg.email}");
                Out.WriteLine($"   2. Password (secret)             : {Mask(cfg.password)}");
                Out.WriteLine($"   3. App password (secret)         : {Mask(cfg.server?.application_specific_password)}");
                Out.WriteLine($"   4. Archive folder                : {cfg.archive_folder}");
                Out.WriteLine($"   5. Archive index folder          : {cfg.archive_index_folder}");
                Out.WriteLine($"   6. Attachments folder            : {cfg.archive_attachments_folder}");
                Out.WriteLine($"   7. Archive structure             : {cfg.archive_structure}");
                Out.WriteLine($"   8. Max emails/minute             : {cfg.performance?.max_emails_per_minute}");
                Out.WriteLine($"   9. Max attachment MB/minute      : {cfg.performance?.max_attachment_size_in_MB_per_minute}");
                Out.WriteLine($"  10. Pause between requests (s)    : {cfg.performance?.pause_between_requests_in_seconds}");
                Out.WriteLine($"  11. Max retries                  : {cfg.performance?.max_retries}");
                Out.WriteLine($"  12. Log level                    : {cfg.performance?.log_level}");
                Out.WriteLine($"  13. Archive attachments (on/off) : {cfg.archive_attachments}");
                Out.WriteLine( "   S. Save    Q. Quit without saving");
                Out.Write("  Choose: ");
                string c = (Console.ReadLine() ?? string.Empty).Trim().ToUpperInvariant();

                if (c == "Q")
                {
                    if (dirty && !Confirm("  Discard unsaved changes?")) continue;
                    Out.WriteLine("  Edit cancelled."); return;
                }
                if (c == "S")
                {
                    try
                    {
                        Gmail_IMAP_Management_Class.ProtectToFile(cfg.ToJson(), path);
                        Out.WriteLine($"  Saved (DPAPI-protected): {path}");
                    }
                    catch (Exception ex) { Out.WriteLine($"  Save failed: {ex.Message}"); }
                    return;
                }

                cfg.server ??= new Server();
                cfg.performance ??= new Performance();

                switch (c)
                {
                    case "1":  cfg.email = Edit("Email", cfg.email); dirty = true; break;
                    case "2":  { var s = EditSecret("Password"); if (s != null) { cfg.password = s; dirty = true; } break; }
                    case "3":  { var s = EditSecret("App password");
                                 if (s != null)
                                 {
                                     cfg.server.application_specific_password = s;
                                     // keep SMTP secrets in step with the app password
                                     cfg.server.smtp_password = s;
                                     cfg.server.smtp_application_specific_password = s;
                                     dirty = true;
                                 }
                                 break; }
                    case "4":  cfg.archive_folder = Edit("Archive folder", cfg.archive_folder); dirty = true; break;
                    case "5":  cfg.archive_index_folder = Edit("Index folder", cfg.archive_index_folder); dirty = true; break;
                    case "6":  cfg.archive_attachments_folder = Edit("Attachments folder", cfg.archive_attachments_folder); dirty = true; break;
                    case "7":  cfg.archive_structure = Edit("Archive structure", cfg.archive_structure); dirty = true; break;
                    case "8":  cfg.performance.max_emails_per_minute = EditLong("Max emails/minute", cfg.performance.max_emails_per_minute); dirty = true; break;
                    case "9":  cfg.performance.max_attachment_size_in_MB_per_minute = EditLong("Max attachment MB/minute", cfg.performance.max_attachment_size_in_MB_per_minute); dirty = true; break;
                    case "10": cfg.performance.pause_between_requests_in_seconds = EditLong("Pause (s)", cfg.performance.pause_between_requests_in_seconds); dirty = true; break;
                    case "11": cfg.performance.max_retries = EditLong("Max retries", cfg.performance.max_retries); dirty = true; break;
                    case "12": cfg.performance.log_level = Edit("Log level", cfg.performance.log_level); dirty = true; break;
                    case "13": cfg.archive_attachments = !(cfg.archive_attachments ?? true);
                               Out.WriteLine($"  Archive attachments -> {cfg.archive_attachments}"); dirty = true; break;
                    default:   Out.WriteLine("  Unrecognized option."); break;
                }
            }
        }

        // =====================================================================
        // ITEM 2 — Retry errors found in the logs
        // =====================================================================
        /// <summary>
        /// Reads the per-account failure log, reconnects to Gmail, and re-fetches + re-processes each
        /// unresolved UID using the same defensive parse and store path. Successful UIDs are marked
        /// resolved so repeated runs converge. Returns true if all attempted UIDs now succeed.
        /// </summary>
        public static bool RetryLoggedErrors(Configuration_Definition_Container cfg, Archive_Store store)
        {
            if (cfg == null || store == null) { Out.WriteLine("  No active configuration."); return false; }

            var log = new Failure_Log(store.ArchiveFolder, store.AccountKey);
            var pending = log.UnresolvedDistinct();
            if (pending.Count == 0)
            {
                Out.WriteLine("  No unresolved errors in the log. Nothing to retry.");
                return true;
            }

            Out.WriteLine($"  {pending.Count} unresolved error(s) in the log:");
            foreach (var e in pending.Take(20))
                Out.WriteLine($"    UID {e.uid}  [{e.folder}]  {Trunc(e.reason, 60)}");
            if (pending.Count > 20) Out.WriteLine($"    … and {pending.Count - 20} more.");
            if (!Confirm("  Retry these now?")) { Out.WriteLine("  Cancelled."); return false; }

            var engine = new Gmail_Fetch_Engine(cfg, store, Out);
            var resolved = new List<uint>();
            int ok = 0, still = 0;

            // Group by folder so we open each mailbox once.
            foreach (var group in pending.GroupBy(e => string.IsNullOrEmpty(e.folder) ? "[Gmail]/All Mail" : e.folder))
            {
                ImapClient client = null;
                IMailFolder folder = null;
                try
                {
                    client = engine.Connect();
                    folder = client.GetFolder(group.Key);
                    folder.Open(FolderAccess.ReadOnly);

                    foreach (var entry in group)
                    {
                        var uid = new UniqueId(folder.UidValidity, entry.uid);
                        try
                        {
                            bool success = engine.RetryOne(folder, uid);
                            if (success) { resolved.Add(entry.uid); ok++; }
                            else still++;
                        }
                        catch (Exception ex)
                        {
                            still++;
                            Out.WriteLine($"    UID {entry.uid} still failing: {ex.Message}");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Out.WriteLine($"  Could not process folder '{group.Key}': {ex.Message}");
                }
                finally
                {
                    try { folder?.Close(); } catch { }
                    try { client?.Disconnect(true); } catch { }
                    client?.Dispose();
                }
            }

            if (resolved.Count > 0)
            {
                store.Index.Commit();
                store.SaveManifest();
                log.MarkResolved(resolved);
            }

            Out.WriteLine($"  Retry complete. Recovered: {ok}. Still failing: {still}.");
            return still == 0;
        }

        // ---- small console helpers ---------------------------------------
        private static string Edit(string label, string current)
        {
            Out.Write($"  {label} [{current}]: ");
            string v = (Console.ReadLine() ?? string.Empty).Trim();
            return string.IsNullOrEmpty(v) ? current : v;
        }

        private static long? EditLong(string label, long? current)
        {
            Out.Write($"  {label} [{current}]: ");
            string v = (Console.ReadLine() ?? string.Empty).Trim();
            if (string.IsNullOrEmpty(v)) return current;
            return long.TryParse(v, out long n) ? n : current;
        }

        private static string EditSecret(string label)
        {
            Out.Write($"  {label} (masked, Enter to keep): ");
            var sb = new System.Text.StringBuilder();
            ConsoleKeyInfo k;
            while ((k = Console.ReadKey(true)).Key != ConsoleKey.Enter)
            {
                if (k.Key == ConsoleKey.Backspace) { if (sb.Length > 0) { sb.Length--; Out.Write("\b \b"); } }
                else if (!char.IsControl(k.KeyChar)) { sb.Append(k.KeyChar); Out.Write('*'); }
            }
            Out.WriteLine();
            return sb.Length == 0 ? null : sb.ToString();
        }

        private static bool Confirm(string prompt)
        {
            Out.Write($"{prompt} (y/N): ");
            string v = (Console.ReadLine() ?? string.Empty).Trim().ToLowerInvariant();
            return v == "y" || v == "yes";
        }

        private static string Mask(string s) =>
            string.IsNullOrEmpty(s) ? "(unset)" : new string('•', Math.Min(s.Length, 12));

        private static string Trunc(string s, int n) =>
            string.IsNullOrEmpty(s) ? "" : (s.Length <= n ? s : s.Substring(0, n - 1) + "…");
    }
}
